create definer = root@localhost view dept5emp_check as
select `company`.`employee`.`fname`    AS `fname`,
       `company`.`employee`.`lname`    AS `lname`,
       `company`.`employee`.`ssn`      AS `ssn`,
       `company`.`employee`.`bdate`    AS `bdate`,
       `company`.`employee`.`address`  AS `address`,
       `company`.`employee`.`sex`      AS `sex`,
       `company`.`employee`.`salary`   AS `salary`,
       `company`.`employee`.`superssn` AS `superssn`,
       `company`.`employee`.`dno`      AS `dno`
from `company`.`employee`
where (`company`.`employee`.`dno` = 5);

