create
    definer = root@localhost procedure find_my_employees(IN my_ssn decimal(9))
BEGIN
SELECT * FROM employee WHERE superssn = my_ssn;
END;

