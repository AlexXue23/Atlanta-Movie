create definer = root@localhost view dept_info as
select `company`.`department`.`dname`     AS `dname`,
       count(0)                           AS `count(*)`,
       sum(`company`.`employee`.`salary`) AS `sum(salary)`
from `company`.`department`
         join `company`.`employee`
where (`company`.`department`.`dnumber` = `company`.`employee`.`dno`)
group by `company`.`department`.`dname`;

