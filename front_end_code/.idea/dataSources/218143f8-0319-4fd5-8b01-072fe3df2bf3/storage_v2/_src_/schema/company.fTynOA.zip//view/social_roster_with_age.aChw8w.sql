create definer = root@localhost view social_roster_with_age as
select `company`.`employee`.`fname`             AS `fname`,
       `company`.`employee`.`lname`             AS `lname`,
       `company`.`employee`.`bdate`             AS `bdate`,
       `company`.`employee`.`address`           AS `address`,
       `company`.`employee`.`sex`               AS `sex`,
       `calc_age`(`company`.`employee`.`bdate`) AS `age`
from `company`.`employee`;

