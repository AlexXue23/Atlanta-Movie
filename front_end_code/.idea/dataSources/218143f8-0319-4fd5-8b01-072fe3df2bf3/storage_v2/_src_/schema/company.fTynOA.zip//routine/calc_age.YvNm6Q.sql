create
    definer = root@localhost function calc_age(my_date date) returns int
BEGIN
RETURN truncate(datediff(utc_date(), my_date) / 365, 0);
END;

