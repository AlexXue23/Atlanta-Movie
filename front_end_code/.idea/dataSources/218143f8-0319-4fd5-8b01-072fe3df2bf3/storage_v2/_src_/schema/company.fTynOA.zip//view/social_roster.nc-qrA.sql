create definer = root@localhost view social_roster as
select `company`.`employee`.`fname`   AS `fname`,
       `company`.`employee`.`lname`   AS `lname`,
       `company`.`employee`.`bdate`   AS `bdate`,
       `company`.`employee`.`address` AS `address`,
       `company`.`employee`.`sex`     AS `sex`
from `company`.`employee`;

