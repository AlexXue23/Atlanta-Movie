create
    definer = root@localhost procedure test_proc(IN my_ssn decimal(9))
BEGIN
  select * from employee where superssn = myssn;
END;

