create definer = root@localhost view works_on1 as
select `company`.`employee`.`fname` AS `fname`,
       `company`.`employee`.`lname` AS `lname`,
       `company`.`project`.`pname`  AS `pname`,
       `company`.`works_on`.`hours` AS `hours`
from `company`.`employee`
         join `company`.`project`
         join `company`.`works_on`
where ((`company`.`employee`.`ssn` = `company`.`works_on`.`essn`) and
       (`company`.`works_on`.`pno` = `company`.`project`.`pnumber`));

