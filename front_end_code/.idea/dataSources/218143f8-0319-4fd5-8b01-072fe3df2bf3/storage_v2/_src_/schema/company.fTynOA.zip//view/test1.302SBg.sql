create definer = root@localhost view test1 as
select `social_roster`.`fname`   AS `fname`,
       `social_roster`.`lname`   AS `lname`,
       `social_roster`.`bdate`   AS `bdate`,
       `social_roster`.`address` AS `address`,
       `social_roster`.`sex`     AS `sex`
from `company`.`social_roster`;

