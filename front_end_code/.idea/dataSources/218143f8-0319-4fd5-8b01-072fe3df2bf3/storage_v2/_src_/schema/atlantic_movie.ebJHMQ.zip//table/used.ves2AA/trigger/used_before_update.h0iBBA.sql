create definer = root@localhost trigger used_BEFORE_UPDATE
    before UPDATE
    on used
    for each row
BEGIN

END;

