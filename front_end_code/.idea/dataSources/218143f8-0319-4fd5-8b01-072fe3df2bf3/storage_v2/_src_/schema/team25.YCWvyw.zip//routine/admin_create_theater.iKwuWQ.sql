create
    definer = root@localhost procedure admin_create_theater(IN i_thName varchar(50), IN i_comName varchar(50),
                                                            IN i_thStreet varchar(50), IN i_thCity varchar(50),
                                                            IN i_thState char(2), IN i_thZipcode char(5),
                                                            IN i_capacity int(10), IN i_managerUsername varchar(50))
BEGIN
	insert into theater (theaterName, companyName, capacity, theaterState, theaterCity, theaterStreet, theaterZipcode, managerID)
    values (i_thName, i_comName, i_capacity, i_thState, i_thCity, i_thStreet, i_thZipcode, i_managerUsername);
END;

