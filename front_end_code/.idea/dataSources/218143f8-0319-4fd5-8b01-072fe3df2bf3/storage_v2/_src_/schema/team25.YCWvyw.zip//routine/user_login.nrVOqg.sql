create
    definer = root@localhost procedure user_login(IN i_username varchar(50), IN i_password varchar(50))
BEGIN
		DROP TABLE IF EXISTS userLogin;
        CREATE TABLE UserLogin
        SELECT username, status
        FROM users
        WHERE (username = i_username) AND (password = i_password);
        ALTER TABLE UserLogin ADD isCustomer INT(1) DEFAULT 0, ADD isAdmin INT(1) DEFAULT 0, ADD isManager INT(1) DEFAULT 0;
        ALTER TABLE UserLogin ADD PRIMARY KEY (username);
        UPDATE UserLogin SET isCustomer = 1
        WHERE (username = i_username) AND i_username IN (SELECT username FROM customer);
        UPDATE UserLogin SET isAdmin = 1
        WHERE (username = i_username) AND i_username IN (SELECT username FROM admin);
        UPDATE UserLogin SET isManager = 1
        WHERE (username = i_username) AND i_username IN (SELECT username FROM manager);
END;

