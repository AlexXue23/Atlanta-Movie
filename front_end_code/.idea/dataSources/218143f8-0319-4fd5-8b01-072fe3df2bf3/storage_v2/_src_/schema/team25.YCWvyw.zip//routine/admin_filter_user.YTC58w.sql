create
    definer = root@localhost procedure admin_filter_user(IN i_username varchar(50), IN i_status char(10),
                                                         IN i_sortBy char(20), IN i_sortDirection char(10))
BEGIN
	drop table if exists AdFilterUser;
    if i_sortBy = '' then set i_sortBy = "username"; end if;
    if i_sortDirection = '' then set i_sortDirection = "DESC"; end if;
    
    create table AdFilterUser;
    select username, creditCardCount, status
    from (
    select username, count(creditCardNum) as creditCardCount, status 
    from users
    left join creditcard 
    on users.username = creditcard.username group by username) as table1
    where username = i_username;
END;

