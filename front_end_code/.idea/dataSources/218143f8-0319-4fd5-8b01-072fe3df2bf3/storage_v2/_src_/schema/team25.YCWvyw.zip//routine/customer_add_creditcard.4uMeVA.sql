create
    definer = root@localhost procedure customer_add_creditcard(IN i_username varchar(50), IN i_creditCardNum char(16))
BEGIN
	INSERT INTO creditcard (username, creditCardNum) 
    VALUES (i_username, i_creditCardNum);
END;

