create
    definer = root@localhost procedure admin_decline_user(IN i_username varchar(50))
BEGIN
	update users set status = "Declined"
    where username = i_username;
END;

