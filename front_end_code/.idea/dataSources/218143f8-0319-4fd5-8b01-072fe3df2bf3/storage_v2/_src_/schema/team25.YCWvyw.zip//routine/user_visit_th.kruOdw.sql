create
    definer = root@localhost procedure user_visit_th(IN i_thName varchar(50), IN i_comName varchar(50),
                                                     IN i_visitDate date, IN i_username varchar(50))
BEGIN
    INSERT INTO UserVisitTheater (thName, comName, visitDate, username)
    VALUES (i_thName, i_comName, i_visitDate, i_username);
END;

