create
    definer = root@localhost procedure customer_only_register(IN i_username varchar(50), IN i_password varchar(50),
                                                              IN i_firstname varchar(50), IN i_lastname varchar(50))
BEGIN
	INSERT INTO users (username, password, firstName, lastName) 
    VALUES (i_username, MD5(i_password), i_firstname, i_lastname);
    INSERT INTO customer (username)
    VALUES (i_username);
END;

