create
    definer = root@localhost procedure manager_customer_register(IN i_username varchar(50), IN i_password varchar(50),
                                                                 IN i_firstname varchar(50), IN i_lastname varchar(50),
                                                                 IN i_comName varchar(50), IN i_empStreet varchar(50),
                                                                 IN i_empCity varchar(50), IN i_empState char(2),
                                                                 IN i_empZipcode char(5))
BEGIN
	INSERT INTO users (username, password, firstName, lastName)
    VALUES (i_username, MD5(i_password), i_firstname, i_lastname);
    INSERT INTO employee (username)
    VALUES (i_username);
    INSERT INTO manager (username, managerState, managerCity, managerStreet, managerZipcode, companyName)
    VALUES (i_username, i_empState, i_empCity, i_empStreet, i_empZipcode, i_comName); 
    INSERT INTO customer (username)
    VALUES (i_username);
END;

